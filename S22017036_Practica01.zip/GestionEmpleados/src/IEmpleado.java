public interface IEmpleado  {
    public double calcularIncentivo();
}
